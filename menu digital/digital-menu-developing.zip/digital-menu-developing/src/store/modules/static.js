
export default {
  namespaced: true,
  state: {
    phone: '+5598988998019',
    instagram: 'https://www.instagram.com/pizzariacolosso/?igshid=1h7f4x1saumts',
  },
  actions: {},
  gettets: {},
}
